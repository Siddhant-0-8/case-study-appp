// import logo from './logo.svg';
import './App.css';
import Appbar from "./components/Appbar"
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <div className="App">
      <Appbar />


    </div>
  );
}

export default App;
